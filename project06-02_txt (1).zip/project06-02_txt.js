"use strict";
/*    JavaScript 7th Edition
      Chapter 6
      Project 06-02

      Project to turn a selection list into a selection of hypertext links
      Author: Atsu akligo
      Date: 22 February 2024

      Filename: project06-02.js
*/


document.addEventListener('DOMContentLoaded', () =>{
      
      let allSelect = document.querySelectorAll('#govLinks select')
      
      for (let i = 0; i < allSelect.length; i++) { 

            allSelect[i].addEventListener('change', (evt)=>{
                  
                  let linkURL  = evt.target.value
                  window.open(linkURL)
            })
      }
}
);